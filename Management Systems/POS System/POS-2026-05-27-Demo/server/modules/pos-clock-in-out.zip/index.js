class ClockInOutModule {
  constructor() {
    this.name = 'pos-clock-in-out';
    this.version = '1.0.0';
    this.dbConnector = null; // Database connector (supports local/remote)
    this.db = null; // Legacy support (deprecated)
  }

  // Initialize the module
  initialize(moduleManager, dbConnector = null) {
    this.moduleManager = moduleManager;
    
    // Use dbConnector (supports local/remote database)
    if (dbConnector) {
      this.dbConnector = dbConnector;
    } else if (moduleManager && moduleManager.dbConnector) {
      this.dbConnector = moduleManager.dbConnector;
    }
    
    console.log(`Clock In/Out module initialized${this.dbConnector ? ' with database connector (local/remote support)' : ' (database connection pending)'}`);
    
    // Create database tables
    if (this.dbConnector) {
      this.migrateDatabase();
    }
    
    // Register API routes
    this.routes = this.getRoutes();
  }

  // Migrate database to create time_tracking table
  async migrateDatabase() {
    try {
      const dbConnector = this.getDatabaseConnector();
      if (!dbConnector) return;

      // Create time_tracking table
      try {
        await dbConnector.run(`
          CREATE TABLE IF NOT EXISTS time_tracking (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            clock_in_time DATETIME NOT NULL,
            clock_out_time DATETIME,
            total_hours REAL,
            notes TEXT,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id)
          )
        `);
        console.log('Time tracking table created or already exists');
      } catch (err) {
        console.error('Error creating time_tracking table:', err);
      }

      // Create indexes for faster queries
      try {
        await dbConnector.run(`
          CREATE INDEX IF NOT EXISTS idx_time_tracking_user_id 
          ON time_tracking(user_id)
        `);
      } catch (err) {
        console.error('Error creating index:', err);
      }

      try {
        await dbConnector.run(`
          CREATE INDEX IF NOT EXISTS idx_time_tracking_clock_in 
          ON time_tracking(clock_in_time)
        `);
      } catch (err) {
        console.error('Error creating index:', err);
      }
    } catch (error) {
      console.error('Error in database migration:', error);
    }
  }

  // Get API routes for this module
  getRoutes() {
    return [
      // Clock In/Out Routes
      {
        method: 'POST',
        path: '/clock-in-out/clock-in',
        handler: this.clockIn.bind(this),
        middleware: [this.requireAuth.bind(this)]
      },
      {
        method: 'POST',
        path: '/clock-in-out/clock-out',
        handler: this.clockOut.bind(this),
        middleware: [this.requireAuth.bind(this)]
      },
      {
        method: 'GET',
        path: '/clock-in-out/status',
        handler: this.getClockStatus.bind(this),
        middleware: [this.requireAuth.bind(this)]
      },
      {
        method: 'GET',
        path: '/clock-in-out/timesheets',
        handler: this.getTimesheets.bind(this),
        middleware: [this.requireAuth.bind(this)]
      },
      {
        method: 'GET',
        path: '/clock-in-out/timesheets/:id',
        handler: this.getTimesheet.bind(this),
        middleware: [this.requireAuth.bind(this)]
      },
      {
        method: 'PUT',
        path: '/clock-in-out/timesheets/:id',
        handler: this.updateTimesheet.bind(this),
        middleware: [this.requireAuth.bind(this), this.requireRole(['admin', 'manager'])]
      },
      {
        method: 'DELETE',
        path: '/clock-in-out/timesheets/:id',
        handler: this.deleteTimesheet.bind(this),
        middleware: [this.requireAuth.bind(this), this.requireRole(['admin', 'manager'])]
      },
      {
        method: 'GET',
        path: '/clock-in-out/timesheets/user/:userId',
        handler: this.getUserTimesheets.bind(this),
        middleware: [this.requireAuth.bind(this)]
      },
      {
        method: 'GET',
        path: '/clock-in-out/settings',
        handler: this.getSettings.bind(this),
        middleware: [this.requireAuth.bind(this)]
      }
    ];
  }

  // Middleware: Require authentication
  requireAuth(req, res, next) {
    if (req.session && req.session.user) {
      req.user = req.session.user;
      return next();
    }
    return res.status(401).json({
      success: false,
      error: 'Authentication required'
    });
  }

  // Middleware: Require specific role(s)
  requireRole(roles) {
    return (req, res, next) => {
      if (!req.user) {
        return res.status(401).json({
          success: false,
          error: 'Authentication required'
        });
      }

      const userRole = req.user.role;
      const allowedRoles = Array.isArray(roles) ? roles : [roles];
      
      if (allowedRoles.includes(userRole)) {
        return next();
      }
      
      return res.status(403).json({
        success: false,
        error: 'Insufficient permissions. Required role: ' + allowedRoles.join(' or ')
      });
    };
  }

  // Get database connector instance (supports local/remote)
  getDatabaseConnector() {
    if (this.dbConnector) {
      return this.dbConnector;
    }
    
    if (this.moduleManager && this.moduleManager.dbConnector) {
      return this.moduleManager.dbConnector;
    }
    
    return null;
  }

  // Legacy method for backward compatibility (deprecated - use getDatabaseConnector)
  getDatabase() {
    return null; // Force modules to use dbConnector
  }

  // Clock In
  async clockIn(req, res) {
    try {
      const dbConnector = this.getDatabaseConnector();
      if (!dbConnector) {
        return res.status(500).json({
          success: false,
          error: 'Database access not configured'
        });
      }

      const userId = req.user.id;
      const { notes } = req.body || {};

      // Check if user is already clocked in
      const activeEntry = await dbConnector.get(
        `SELECT id, clock_in_time, clock_out_time 
         FROM time_tracking 
         WHERE user_id = ? AND clock_out_time IS NULL 
         ORDER BY clock_in_time DESC 
         LIMIT 1`,
        [userId]
      );

      const settings = this.moduleManager.moduleConfigs.get(this.name)?.settings || {};
      // Helper to get setting value (handles both schema objects and direct values)
      const getSettingValue = (key, defaultValue) => {
        const setting = settings[key];
        if (setting === undefined || setting === null) return defaultValue;
        if (typeof setting === 'object' && setting !== null && 'default' in setting) {
          return setting.default;
        }
        return setting;
      };
      const requireClockOut = getSettingValue('requireClockOutBeforeClockIn', true);

      if (activeEntry && !activeEntry.clock_out_time && requireClockOut) {
        return res.status(400).json({
          success: false,
          error: 'You are already clocked in. Please clock out first.',
          activeEntry: {
            id: activeEntry.id,
            clockInTime: activeEntry.clock_in_time
          }
        });
      }

      // Insert new clock in entry
      const clockInTime = new Date().toISOString();
      const result = await dbConnector.run(
        `INSERT INTO time_tracking (user_id, clock_in_time, notes, created_at, updated_at) 
         VALUES (?, ?, ?, datetime('now'), datetime('now'))`,
        [userId, clockInTime, notes || null]
      );

      res.json({
        success: true,
        message: 'Clocked in successfully',
        entry: {
          id: result.lastID,
          userId: userId,
          clockInTime: clockInTime,
          clockOutTime: null
        }
      });
    } catch (error) {
      console.error('Error in clockIn:', error);
      res.status(500).json({
        success: false,
        error: error.message
      });
    }
  }

  // Clock Out
  async clockOut(req, res) {
    try {
      const dbConnector = this.getDatabaseConnector();
      if (!dbConnector) {
        return res.status(500).json({
          success: false,
          error: 'Database access not configured'
        });
      }

      const userId = req.user.id;
      const { notes } = req.body || {};

      // Find active clock in entry
      const activeEntry = await dbConnector.get(
        `SELECT id, clock_in_time 
         FROM time_tracking 
         WHERE user_id = ? AND clock_out_time IS NULL 
         ORDER BY clock_in_time DESC 
         LIMIT 1`,
        [userId]
      );

      if (!activeEntry) {
        return res.status(400).json({
          success: false,
          error: 'No active clock in entry found. Please clock in first.'
        });
      }

      // Calculate total hours
      const clockInTime = new Date(activeEntry.clock_in_time);
      const clockOutTime = new Date();
      const totalHours = (clockOutTime - clockInTime) / (1000 * 60 * 60); // Convert to hours

      // Update entry with clock out time
      const clockOutTimeStr = clockOutTime.toISOString();
      await dbConnector.run(
        `UPDATE time_tracking 
         SET clock_out_time = ?, 
             total_hours = ?, 
             notes = COALESCE(?, notes),
             updated_at = datetime('now')
         WHERE id = ?`,
        [clockOutTimeStr, totalHours, notes || null, activeEntry.id]
      );

      res.json({
        success: true,
        message: 'Clocked out successfully',
        entry: {
          id: activeEntry.id,
          userId: userId,
          clockInTime: activeEntry.clock_in_time,
          clockOutTime: clockOutTimeStr,
          totalHours: totalHours.toFixed(2)
        }
      });
    } catch (error) {
      console.error('Error in clockOut:', error);
      res.status(500).json({
        success: false,
        error: error.message
      });
    }
  }

  // Get current clock status
  async getClockStatus(req, res) {
    try {
      const dbConnector = this.getDatabaseConnector();
      if (!dbConnector) {
        return res.status(500).json({
          success: false,
          error: 'Database access not configured'
        });
      }

      const userId = req.user.id;

      const activeEntry = await dbConnector.get(
        `SELECT id, clock_in_time, clock_out_time, total_hours 
         FROM time_tracking 
         WHERE user_id = ? AND clock_out_time IS NULL 
         ORDER BY clock_in_time DESC 
         LIMIT 1`,
        [userId]
      );

      res.json({
        success: true,
        isClockedIn: !!activeEntry,
        entry: activeEntry || null
      });
    } catch (error) {
      console.error('Error in getClockStatus:', error);
      res.status(500).json({
        success: false,
        error: error.message
      });
    }
  }

  // Get timesheets
  async getTimesheets(req, res) {
    try {
      const dbConnector = this.getDatabaseConnector();
      if (!dbConnector) {
        return res.status(500).json({
          success: false,
          error: 'Database access not configured'
        });
      }

      const userId = req.user.id;
      const userRole = req.user.role;
      const { startDate, endDate, targetUserId } = req.query;

      // Admins and managers can view all timesheets, others only their own
      let query = `
        SELECT 
          t.id,
          t.user_id,
          t.clock_in_time,
          t.clock_out_time,
          t.total_hours,
          t.notes,
          t.created_at,
          t.updated_at,
          u.username,
          u.full_name
        FROM time_tracking t
        LEFT JOIN users u ON t.user_id = u.id
        WHERE 1=1
      `;
      const params = [];

      // Apply user filter
      if (userRole === 'admin' || userRole === 'manager') {
        if (targetUserId) {
          query += ' AND t.user_id = ?';
          params.push(parseInt(targetUserId));
        }
      } else {
        query += ' AND t.user_id = ?';
        params.push(userId);
      }

      // Apply date filters
      if (startDate) {
        query += ' AND DATE(t.clock_in_time) >= ?';
        params.push(startDate);
      }

      if (endDate) {
        query += ' AND DATE(t.clock_in_time) <= ?';
        params.push(endDate);
      }

      query += ' ORDER BY t.clock_in_time DESC LIMIT 500';

      const rows = await dbConnector.query(query, params);
      res.json({
        success: true,
        timesheets: rows
      });
    } catch (error) {
      console.error('Error in getTimesheets:', error);
      res.status(500).json({
        success: false,
        error: error.message
      });
    }
  }

  // Get single timesheet
  async getTimesheet(req, res) {
    try {
      const dbConnector = this.getDatabaseConnector();
      if (!dbConnector) {
        return res.status(500).json({
          success: false,
          error: 'Database access not configured'
        });
      }

      const { id } = req.params;
      const userId = req.user.id;
      const userRole = req.user.role;

      const timesheet = await dbConnector.get(
        `SELECT 
          t.id,
          t.user_id,
          t.clock_in_time,
          t.clock_out_time,
          t.total_hours,
          t.notes,
          t.created_at,
          t.updated_at,
          u.username,
          u.full_name
         FROM time_tracking t
         LEFT JOIN users u ON t.user_id = u.id
         WHERE t.id = ?`,
        [parseInt(id)]
      );

      if (!timesheet) {
        return res.status(404).json({
          success: false,
          error: 'Timesheet not found'
        });
      }

      // Users can only view their own timesheets unless admin/manager
      if (userRole !== 'admin' && userRole !== 'manager' && timesheet.user_id !== userId) {
        return res.status(403).json({
          success: false,
          error: 'You can only view your own timesheets'
        });
      }

      res.json({
        success: true,
        timesheet: timesheet
      });
    } catch (error) {
      console.error('Error in getTimesheet:', error);
      res.status(500).json({
        success: false,
        error: error.message
      });
    }
  }

  // Update timesheet (admin/manager only)
  async updateTimesheet(req, res) {
    try {
      const dbConnector = this.getDatabaseConnector();
      if (!dbConnector) {
        return res.status(500).json({
          success: false,
          error: 'Database access not configured'
        });
      }

      const { id } = req.params;
      const { clock_in_time, clock_out_time, notes } = req.body;

      // Get existing timesheet
      const existing = await dbConnector.get('SELECT * FROM time_tracking WHERE id = ?', [parseInt(id)]);

      if (!existing) {
        return res.status(404).json({
          success: false,
          error: 'Timesheet not found'
        });
      }

      // Calculate total hours if both times are provided
      let totalHours = existing.total_hours;
      if (clock_in_time && clock_out_time) {
        const clockIn = new Date(clock_in_time);
        const clockOut = new Date(clock_out_time);
        totalHours = (clockOut - clockIn) / (1000 * 60 * 60);
      } else if (clock_in_time && existing.clock_out_time) {
        const clockIn = new Date(clock_in_time);
        const clockOut = new Date(existing.clock_out_time);
        totalHours = (clockOut - clockIn) / (1000 * 60 * 60);
      } else if (clock_out_time && existing.clock_in_time) {
        const clockIn = new Date(existing.clock_in_time);
        const clockOut = new Date(clock_out_time);
        totalHours = (clockOut - clockIn) / (1000 * 60 * 60);
      }

      // Build update query
      const updates = [];
      const params = [];

      if (clock_in_time !== undefined) {
        updates.push('clock_in_time = ?');
        params.push(clock_in_time);
      }

      if (clock_out_time !== undefined) {
        updates.push('clock_out_time = ?');
        params.push(clock_out_time);
      }

      if (notes !== undefined) {
        updates.push('notes = ?');
        params.push(notes);
      }

      if (totalHours !== undefined) {
        updates.push('total_hours = ?');
        params.push(totalHours);
      }

      if (updates.length === 0) {
        return res.status(400).json({
          success: false,
          error: 'No fields to update'
        });
      }

      updates.push('updated_at = datetime(\'now\')');
      params.push(parseInt(id));

      const query = `UPDATE time_tracking SET ${updates.join(', ')} WHERE id = ?`;

      await dbConnector.run(query, params);

      // Fetch updated timesheet
      const updated = await dbConnector.get(
        `SELECT 
          t.id,
          t.user_id,
          t.clock_in_time,
          t.clock_out_time,
          t.total_hours,
          t.notes,
          t.created_at,
          t.updated_at,
          u.username,
          u.full_name
         FROM time_tracking t
         LEFT JOIN users u ON t.user_id = u.id
         WHERE t.id = ?`,
        [parseInt(id)]
      );

      res.json({
        success: true,
        message: 'Timesheet updated successfully',
        timesheet: updated
      });
    } catch (error) {
      console.error('Error in updateTimesheet:', error);
      res.status(500).json({
        success: false,
        error: error.message
      });
    }
  }

  // Delete timesheet (admin/manager only)
  async deleteTimesheet(req, res) {
    try {
      const dbConnector = this.getDatabaseConnector();
      if (!dbConnector) {
        return res.status(500).json({
          success: false,
          error: 'Database access not configured'
        });
      }

      const { id } = req.params;

      const result = await dbConnector.run('DELETE FROM time_tracking WHERE id = ?', [parseInt(id)]);

      if (result.changes === 0) {
        return res.status(404).json({
          success: false,
          error: 'Timesheet not found'
        });
      }

      res.json({
        success: true,
        message: 'Timesheet deleted successfully'
      });
    } catch (error) {
      console.error('Error in deleteTimesheet:', error);
      res.status(500).json({
        success: false,
        error: error.message
      });
    }
  }

  // Get user timesheets
  async getUserTimesheets(req, res) {
    try {
      const dbConnector = this.getDatabaseConnector();
      if (!dbConnector) {
        return res.status(500).json({
          success: false,
          error: 'Database access not configured'
        });
      }

      const { userId } = req.params;
      const currentUserId = req.user.id;
      const userRole = req.user.role;

      // Only admins/managers can view other users' timesheets
      if (userRole !== 'admin' && userRole !== 'manager' && parseInt(userId) !== currentUserId) {
        return res.status(403).json({
          success: false,
          error: 'You can only view your own timesheets'
        });
      }

      const { startDate, endDate } = req.query;

      let query = `
        SELECT 
          t.id,
          t.user_id,
          t.clock_in_time,
          t.clock_out_time,
          t.total_hours,
          t.notes,
          t.created_at,
          t.updated_at,
          u.username,
          u.full_name
        FROM time_tracking t
        LEFT JOIN users u ON t.user_id = u.id
        WHERE t.user_id = ?
      `;
      const params = [parseInt(userId)];

      if (startDate) {
        query += ' AND DATE(t.clock_in_time) >= ?';
        params.push(startDate);
      }

      if (endDate) {
        query += ' AND DATE(t.clock_in_time) <= ?';
        params.push(endDate);
      }

      query += ' ORDER BY t.clock_in_time DESC LIMIT 500';

      const rows = await dbConnector.query(query, params);
      res.json({
        success: true,
        timesheets: rows
      });
    } catch (error) {
      console.error('Error in getUserTimesheets:', error);
      res.status(500).json({
        success: false,
        error: error.message
      });
    }
  }

  // Get module settings
  async getSettings(req, res) {
    try {
      const settings = this.moduleManager.moduleConfigs.get(this.name)?.settings || {};
      
      // Helper function to get setting value (handles both schema objects and direct values)
      const getSettingValue = (key, defaultValue) => {
        const setting = settings[key];
        if (setting === undefined || setting === null) {
          return defaultValue;
        }
        // If it's a schema object with a default property
        if (typeof setting === 'object' && setting !== null && 'default' in setting) {
          return setting.default;
        }
        // If it's a direct value
        return setting;
      };
      
      res.json({
        success: true,
        settings: {
          showClockInPromptOnLogin: getSettingValue('showClockInPromptOnLogin', true),
          showClockOutPromptOnLogout: getSettingValue('showClockOutPromptOnLogout', true),
          autoClockInOnLogin: getSettingValue('autoClockInOnLogin', false),
          autoClockOutOnLogout: getSettingValue('autoClockOutOnLogout', false),
          requireClockOutBeforeClockIn: getSettingValue('requireClockOutBeforeClockIn', true),
          allowManualClockInOut: getSettingValue('allowManualClockInOut', true),
          enableTimesheetEditing: getSettingValue('enableTimesheetEditing', true)
        }
      });
    } catch (error) {
      console.error('Error in getSettings:', error);
      res.status(500).json({
        success: false,
        error: error.message
      });
    }
  }

  // Get frontend components provided by this module
  getFrontendComponents() {
    return {
      ClockInOutPrompt: './frontend/ClockInOutPrompt',
      TimeSheets: './frontend/TimeSheets',
      ClockInOutSettings: './frontend/ClockInOutSettings',
      metadata: {
        ClockInOutPrompt: {
          name: 'ClockInOutPrompt',
          description: 'Clock in/out prompt modal',
          usage: 'Login/logout flow, manual clock in/out'
        },
        TimeSheets: {
          name: 'TimeSheets',
          description: 'Timesheet management component',
          usage: 'Timesheet page'
        },
        ClockInOutSettings: {
          name: 'ClockInOutSettings',
          description: 'Clock in/out settings component',
          usage: 'Settings page'
        }
      }
    };
  }
}

module.exports = new ClockInOutModule();

