// Frontend components exported by the pos-advanced-reporting module
// These components are dynamically loaded when the module is enabled

export { default as AdvancedReports } from './AdvancedReports';

