class AdvancedReportingModule {
  constructor() {
    this.name = 'pos-advanced-reporting';
    this.version = '1.0.0';
    this.db = null;
  }

  // Initialize the module
  initialize(moduleManager, db = null) {
    this.moduleManager = moduleManager;
    
    if (db) {
      this.db = db;
    } else if (moduleManager && moduleManager.db) {
      this.db = moduleManager.db;
    }
    
    console.log(`Advanced Reporting module initialized${this.db ? ' with database connection' : ' (database connection pending)'}`);
    
    // Register API routes
    this.routes = this.getRoutes();
  }

  // Get database instance
  getDatabase() {
    if (this.db) {
      return this.db;
    }
    
    if (this.moduleManager && this.moduleManager.db) {
      return this.moduleManager.db;
    }
    
    if (typeof global !== 'undefined' && global.posDatabase) {
      return global.posDatabase;
    }
    
    try {
      const mainApp = require('../../index.js');
      if (mainApp && mainApp.db) {
        return mainApp.db;
      }
    } catch (e) {
      // Ignore if we can't access main app
    }
    
    return null;
  }

  // Get API routes for this module
  getRoutes() {
    return [
      // Advanced Sales Reports
      {
        method: 'GET',
        path: '/advanced-reporting/sales/advanced',
        handler: this.getAdvancedSalesReport.bind(this),
        middleware: [this.requireAuth.bind(this)]
      },
      {
        method: 'GET',
        path: '/advanced-reporting/sales/by-product',
        handler: this.getSalesByProduct.bind(this),
        middleware: [this.requireAuth.bind(this)]
      },
      {
        method: 'GET',
        path: '/advanced-reporting/sales/by-user',
        handler: this.getSalesByUser.bind(this),
        middleware: [this.requireAuth.bind(this)]
      },
      {
        method: 'GET',
        path: '/advanced-reporting/sales/by-payment-method',
        handler: this.getSalesByPaymentMethod.bind(this),
        middleware: [this.requireAuth.bind(this)]
      },
      {
        method: 'GET',
        path: '/advanced-reporting/sales/by-category',
        handler: this.getSalesByCategory.bind(this),
        middleware: [this.requireAuth.bind(this)]
      },
      {
        method: 'GET',
        path: '/advanced-reporting/sales/hourly',
        handler: this.getHourlySalesReport.bind(this),
        middleware: [this.requireAuth.bind(this)]
      },
      {
        method: 'GET',
        path: '/advanced-reporting/sales/daily',
        handler: this.getDailySalesReport.bind(this),
        middleware: [this.requireAuth.bind(this)]
      },
      {
        method: 'GET',
        path: '/advanced-reporting/sales/weekly',
        handler: this.getWeeklySalesReport.bind(this),
        middleware: [this.requireAuth.bind(this)]
      },
      {
        method: 'GET',
        path: '/advanced-reporting/sales/monthly',
        handler: this.getMonthlySalesReport.bind(this),
        middleware: [this.requireAuth.bind(this)]
      },
      
      // Product Analytics
      {
        method: 'GET',
        path: '/advanced-reporting/products/top-selling',
        handler: this.getTopSellingProducts.bind(this),
        middleware: [this.requireAuth.bind(this)]
      },
      {
        method: 'GET',
        path: '/advanced-reporting/products/low-selling',
        handler: this.getLowSellingProducts.bind(this),
        middleware: [this.requireAuth.bind(this)]
      },
      {
        method: 'GET',
        path: '/advanced-reporting/products/profitability',
        handler: this.getProductProfitability.bind(this),
        middleware: [this.requireAuth.bind(this)]
      },
      {
        method: 'GET',
        path: '/advanced-reporting/products/category-performance',
        handler: this.getCategoryPerformance.bind(this),
        middleware: [this.requireAuth.bind(this)]
      },
      {
        method: 'GET',
        path: '/advanced-reporting/products/performance-indicators',
        handler: this.getProductPerformanceIndicators.bind(this),
        middleware: [this.requireAuth.bind(this)]
      },
      
      // Comparison Reports
      {
        method: 'GET',
        path: '/advanced-reporting/comparison/period',
        handler: this.getPeriodComparison.bind(this),
        middleware: [this.requireAuth.bind(this)]
      },
      {
        method: 'GET',
        path: '/advanced-reporting/comparison/year-over-year',
        handler: this.getYearOverYearComparison.bind(this),
        middleware: [this.requireAuth.bind(this)]
      },
      
      // Inventory Reports
      {
        method: 'GET',
        path: '/advanced-reporting/inventory/movement',
        handler: this.getInventoryMovement.bind(this),
        middleware: [this.requireAuth.bind(this)]
      },
      {
        method: 'GET',
        path: '/advanced-reporting/inventory/turnover',
        handler: this.getInventoryTurnover.bind(this),
        middleware: [this.requireAuth.bind(this)]
      },
      
      // Export Endpoints
      {
        method: 'GET',
        path: '/advanced-reporting/export/csv',
        handler: this.exportToCSV.bind(this),
        middleware: [this.requireAuth.bind(this)]
      },
      {
        method: 'GET',
        path: '/advanced-reporting/export/json',
        handler: this.exportToJSON.bind(this),
        middleware: [this.requireAuth.bind(this)]
      },
      
      // Dashboard Statistics
      {
        method: 'GET',
        path: '/advanced-reporting/dashboard/stats',
        handler: this.getDashboardStats.bind(this),
        middleware: [this.requireAuth.bind(this)]
      }
    ];
  }

  // Middleware: Require authentication and tenant context
  requireAuth(req, res, next) {
    if (req.session && req.session.user) {
      req.user = req.session.user;
      // Ensure tenant context is available
      if (!req.session.user.tenant_id) {
        return res.status(401).json({
          success: false,
          error: 'Tenant context required'
        });
      }
      req.tenant_id = req.session.user.tenant_id;
      return next();
    }
    return res.status(401).json({
      success: false,
      error: 'Authentication required'
    });
  }

  // Advanced Sales Report with multiple filters
  getAdvancedSalesReport(req, res) {
    try {
      const db = this.getDatabase();
      if (!db) {
        return res.status(500).json({
          success: false,
          error: 'Database access not configured'
        });
      }

      const {
        startDate,
        endDate,
        userId,
        paymentMethod,
        minAmount,
        maxAmount,
        productId,
        category,
        limit = 1000,
        offset = 0
      } = req.query;

      const user = req.user;
      const userRole = user.role;
      const currentUserId = user.id;
      const tenantId = req.tenant_id;

      let query = `
        SELECT
          s.id,
          s.sale_id,
          s.total_amount,
          s.payment_method,
          s.created_at,
          s.user_id,
          u.username,
          u.full_name as user_name,
          COUNT(si.id) as item_count,
          SUM(si.quantity) as total_quantity
        FROM sales s
        LEFT JOIN users u ON s.user_id = u.id
        LEFT JOIN sale_items si ON s.sale_id = si.sale_id
        WHERE s.tenant_id = ?
      `;
      const params = [tenantId];

      // Role-based filtering
      if (userRole === 'cashier') {
        query += ' AND s.user_id = ?';
        params.push(currentUserId);
      }

      // Date filtering
      if (startDate) {
        query += ' AND substr(s.created_at, 1, 10) >= ?';
        params.push(startDate);
      }
      if (endDate) {
        query += ' AND substr(s.created_at, 1, 10) <= ?';
        params.push(endDate);
      }

      // User filtering (admin/manager only)
      if (userId && (userRole === 'admin' || userRole === 'manager')) {
        query += ' AND s.user_id = ?';
        params.push(parseInt(userId));
      }

      // Payment method filtering
      if (paymentMethod) {
        query += ' AND s.payment_method = ?';
        params.push(paymentMethod);
      }

      // Amount filtering
      if (minAmount) {
        query += ' AND s.total_amount >= ?';
        params.push(parseFloat(minAmount));
      }
      if (maxAmount) {
        query += ' AND s.total_amount <= ?';
        params.push(parseFloat(maxAmount));
      }

      // Product filtering
      if (productId) {
        query += ' AND EXISTS (SELECT 1 FROM sale_items si2 WHERE si2.sale_id = s.sale_id AND si2.product_id = ?)';
        params.push(parseInt(productId));
      }

      // Category filtering
      if (category) {
        query += ` AND EXISTS (
          SELECT 1 FROM sale_items si3 
          JOIN products p ON si3.product_id = p.id 
          WHERE si3.sale_id = s.sale_id AND p.category = ?
        )`;
        params.push(category);
      }

      query += ' GROUP BY s.id, s.sale_id, s.total_amount, s.payment_method, s.created_at, s.user_id, u.username, u.full_name';
      query += ' ORDER BY s.created_at DESC';
      query += ' LIMIT ? OFFSET ?';
      params.push(parseInt(limit), parseInt(offset));

      db.all(query, params, (err, rows) => {
        if (err) {
          console.error('Error fetching advanced sales report:', err);
          return res.status(500).json({
            success: false,
            error: 'Failed to fetch sales report'
          });
        }

        // Get total count for pagination
        let countQuery = 'SELECT COUNT(DISTINCT s.id) as total FROM sales s WHERE s.tenant_id = ?';
        const countParams = [tenantId];

        if (userRole === 'cashier') {
          countQuery += ' AND s.user_id = ?';
          countParams.push(currentUserId);
        }

        // Reapply filters for count
        let countIndex = userRole === 'cashier' ? 1 : 0;
        if (startDate) countQuery += ' AND substr(s.created_at, 1, 10) >= ?';
        if (endDate) countQuery += ' AND substr(s.created_at, 1, 10) <= ?';
        if (userId && (userRole === 'admin' || userRole === 'manager')) countQuery += ' AND s.user_id = ?';
        if (paymentMethod) countQuery += ' AND s.payment_method = ?';
        if (minAmount) countQuery += ' AND s.total_amount >= ?';
        if (maxAmount) countQuery += ' AND s.total_amount <= ?';
        if (productId) countQuery += ' AND EXISTS (SELECT 1 FROM sale_items si2 WHERE si2.sale_id = s.sale_id AND si2.product_id = ?)';
        if (category) countQuery += ` AND EXISTS (SELECT 1 FROM sale_items si3 JOIN products p ON si3.product_id = p.id WHERE si3.sale_id = s.sale_id AND p.category = ?)`;

        db.get(countQuery, countParams, (countErr, countRow) => {
          if (countErr) {
            console.error('Error counting sales:', countErr);
          }

          res.json({
            success: true,
            data: rows,
            pagination: {
              total: countRow?.total || rows.length,
              limit: parseInt(limit),
              offset: parseInt(offset),
              hasMore: (countRow?.total || rows.length) > parseInt(offset) + parseInt(limit)
            }
          });
        });
      });
    } catch (error) {
      console.error('Error in getAdvancedSalesReport:', error);
      res.status(500).json({
        success: false,
        error: error.message
      });
    }
  }

  // Sales by Product
  getSalesByProduct(req, res) {
    try {
      const db = this.getDatabase();
      if (!db) {
        return res.status(500).json({
          success: false,
          error: 'Database access not configured'
        });
      }

      const { startDate, endDate, limit = 50 } = req.query;
      const user = req.user;
      const tenantId = req.tenant_id;

      let query = `
        SELECT
          si.product_id,
          si.product_name,
          p.category,
          COUNT(DISTINCT si.sale_id) as sale_count,
          SUM(si.quantity) as total_quantity_sold,
          SUM(si.total_price) as total_revenue,
          AVG(si.unit_price) as avg_price,
          MIN(s.created_at) as first_sale,
          MAX(s.created_at) as last_sale
        FROM sale_items si
        JOIN sales s ON si.sale_id = s.sale_id
        LEFT JOIN products p ON si.product_id = p.id
        WHERE s.tenant_id = ?
      `;
      const params = [tenantId];

      if (user.role === 'cashier') {
        query += ' AND s.user_id = ?';
        params.push(user.id);
      }

      if (startDate) {
        query += ' AND substr(s.created_at, 1, 10) >= ?';
        params.push(startDate);
      }
      if (endDate) {
        query += ' AND substr(s.created_at, 1, 10) <= ?';
        params.push(endDate);
      }

      query += ' GROUP BY si.product_id, si.product_name, p.category';
      query += ' ORDER BY total_revenue DESC';
      query += ' LIMIT ?';
      params.push(parseInt(limit));

      db.all(query, params, (err, rows) => {
        if (err) {
          console.error('Error fetching sales by product:', err);
          return res.status(500).json({
            success: false,
            error: 'Failed to fetch product sales'
          });
        }

        res.json({
          success: true,
          data: rows
        });
      });
    } catch (error) {
      console.error('Error in getSalesByProduct:', error);
      res.status(500).json({
        success: false,
        error: error.message
      });
    }
  }

  // Sales by User
  getSalesByUser(req, res) {
    try {
      const db = this.getDatabase();
      if (!db) {
        return res.status(500).json({
          success: false,
          error: 'Database access not configured'
        });
      }

      const { startDate, endDate } = req.query;
      const user = req.user;
      const tenantId = req.tenant_id;

      if (user.role === 'cashier') {
        return res.status(403).json({
          success: false,
          error: 'Insufficient permissions'
        });
      }

      let query = `
        SELECT
          u.id,
          u.username,
          u.full_name,
          COUNT(s.id) as sale_count,
          SUM(s.total_amount) as total_revenue,
          AVG(s.total_amount) as avg_sale_amount,
          MIN(s.created_at) as first_sale,
          MAX(s.created_at) as last_sale
        FROM users u
        LEFT JOIN sales s ON u.id = s.user_id AND s.tenant_id = ?
        WHERE u.tenant_id = ?
      `;
      const params = [tenantId, tenantId];

      if (startDate) {
        query += ' AND substr(s.created_at, 1, 10) >= ?';
        params.push(startDate);
      }
      if (endDate) {
        query += ' AND substr(s.created_at, 1, 10) <= ?';
        params.push(endDate);
      }

      query += ' GROUP BY u.id, u.username, u.full_name';
      query += ' HAVING sale_count > 0';
      query += ' ORDER BY total_revenue DESC';

      db.all(query, params, (err, rows) => {
        if (err) {
          console.error('Error fetching sales by user:', err);
          return res.status(500).json({
            success: false,
            error: 'Failed to fetch user sales'
          });
        }

        res.json({
          success: true,
          data: rows
        });
      });
    } catch (error) {
      console.error('Error in getSalesByUser:', error);
      res.status(500).json({
        success: false,
        error: error.message
      });
    }
  }

  // Sales by Payment Method
  getSalesByPaymentMethod(req, res) {
    try {
      const db = this.getDatabase();
      if (!db) {
        return res.status(500).json({
          success: false,
          error: 'Database access not configured'
        });
      }

      const { startDate, endDate } = req.query;
      const user = req.user;
      const tenantId = req.tenant_id;

      let query = `
        SELECT
          payment_method,
          COUNT(*) as transaction_count,
          SUM(total_amount) as total_amount,
          AVG(total_amount) as avg_amount,
          MIN(total_amount) as min_amount,
          MAX(total_amount) as max_amount
        FROM sales
        WHERE tenant_id = ?
      `;
      const params = [tenantId];

      if (user.role === 'cashier') {
        query += ' AND user_id = ?';
        params.push(user.id);
      }

      if (startDate) {
        query += ' AND substr(created_at, 1, 10) >= ?';
        params.push(startDate);
      }
      if (endDate) {
        query += ' AND substr(created_at, 1, 10) <= ?';
        params.push(endDate);
      }

      query += ' GROUP BY payment_method';
      query += ' ORDER BY total_amount DESC';

      db.all(query, params, (err, rows) => {
        if (err) {
          console.error('Error fetching sales by payment method:', err);
          return res.status(500).json({
            success: false,
            error: 'Failed to fetch payment method sales'
          });
        }

        res.json({
          success: true,
          data: rows
        });
      });
    } catch (error) {
      console.error('Error in getSalesByPaymentMethod:', error);
      res.status(500).json({
        success: false,
        error: error.message
      });
    }
  }

  // Sales by Category
  getSalesByCategory(req, res) {
    try {
      const db = this.getDatabase();
      if (!db) {
        return res.status(500).json({
          success: false,
          error: 'Database access not configured'
        });
      }

      const { startDate, endDate } = req.query;
      const user = req.user;
      const tenantId = req.tenant_id;

      let query = `
        SELECT
          COALESCE(p.category, 'Uncategorized') as category,
          COUNT(DISTINCT s.sale_id) as sale_count,
          SUM(si.quantity) as total_quantity,
          SUM(si.total_price) as total_revenue,
          AVG(si.unit_price) as avg_price
        FROM sale_items si
        JOIN sales s ON si.sale_id = s.sale_id
        LEFT JOIN products p ON si.product_id = p.id
        WHERE s.tenant_id = ?
      `;
      const params = [tenantId];

      if (user.role === 'cashier') {
        query += ' AND s.user_id = ?';
        params.push(user.id);
      }

      if (startDate) {
        query += ' AND substr(s.created_at, 1, 10) >= ?';
        params.push(startDate);
      }
      if (endDate) {
        query += ' AND substr(s.created_at, 1, 10) <= ?';
        params.push(endDate);
      }

      query += ' GROUP BY p.category';
      query += ' ORDER BY total_revenue DESC';

      db.all(query, params, (err, rows) => {
        if (err) {
          console.error('Error fetching sales by category:', err);
          return res.status(500).json({
            success: false,
            error: 'Failed to fetch category sales'
          });
        }

        res.json({
          success: true,
          data: rows
        });
      });
    } catch (error) {
      console.error('Error in getSalesByCategory:', error);
      res.status(500).json({
        success: false,
        error: error.message
      });
    }
  }

  // Hourly Sales Report
  getHourlySalesReport(req, res) {
    try {
      const db = this.getDatabase();
      if (!db) {
        return res.status(500).json({
          success: false,
          error: 'Database access not configured'
        });
      }

      const { startDate, endDate } = req.query;
      const user = req.user;
      const tenantId = req.tenant_id;

      let query = `
        SELECT
          CAST(strftime('%H', created_at) AS INTEGER) as hour,
          COUNT(*) as sale_count,
          SUM(total_amount) as total_revenue,
          AVG(total_amount) as avg_sale
        FROM sales
        WHERE tenant_id = ?
      `;
      const params = [tenantId];

      if (user.role === 'cashier') {
        query += ' AND user_id = ?';
        params.push(user.id);
      }

      if (startDate) {
        query += ' AND substr(created_at, 1, 10) >= ?';
        params.push(startDate);
      }
      if (endDate) {
        query += ' AND substr(created_at, 1, 10) <= ?';
        params.push(endDate);
      }

      query += ' GROUP BY hour';
      query += ' ORDER BY hour';

      db.all(query, params, (err, rows) => {
        if (err) {
          console.error('Error fetching hourly sales:', err);
          return res.status(500).json({
            success: false,
            error: 'Failed to fetch hourly sales'
          });
        }

        res.json({
          success: true,
          data: rows
        });
      });
    } catch (error) {
      console.error('Error in getHourlySalesReport:', error);
      res.status(500).json({
        success: false,
        error: error.message
      });
    }
  }

  // Daily Sales Report
  getDailySalesReport(req, res) {
    try {
      const db = this.getDatabase();
      if (!db) {
        return res.status(500).json({
          success: false,
          error: 'Database access not configured'
        });
      }

      const { startDate, endDate } = req.query;
      const user = req.user;
      const tenantId = req.tenant_id;

      let query = `
        SELECT
          substr(created_at, 1, 10) as date,
          COUNT(*) as sale_count,
          SUM(total_amount) as total_revenue,
          AVG(total_amount) as avg_sale,
          MIN(total_amount) as min_sale,
          MAX(total_amount) as max_sale
        FROM sales
        WHERE tenant_id = ?
      `;
      const params = [tenantId];

      if (user.role === 'cashier') {
        query += ' AND user_id = ?';
        params.push(user.id);
      }

      if (startDate) {
        query += ' AND substr(created_at, 1, 10) >= ?';
        params.push(startDate);
      }
      if (endDate) {
        query += ' AND substr(created_at, 1, 10) <= ?';
        params.push(endDate);
      }

      query += ' GROUP BY date';
      query += ' ORDER BY date DESC';

      db.all(query, params, (err, rows) => {
        if (err) {
          console.error('Error fetching daily sales:', err);
          return res.status(500).json({
            success: false,
            error: 'Failed to fetch daily sales'
          });
        }

        res.json({
          success: true,
          data: rows
        });
      });
    } catch (error) {
      console.error('Error in getDailySalesReport:', error);
      res.status(500).json({
        success: false,
        error: error.message
      });
    }
  }

  // Weekly Sales Report
  getWeeklySalesReport(req, res) {
    try {
      const db = this.getDatabase();
      if (!db) {
        return res.status(500).json({
          success: false,
          error: 'Database access not configured'
        });
      }

      const { startDate, endDate } = req.query;
      const user = req.user;
      const tenantId = req.tenant_id;

      let query = `
        SELECT
          strftime('%Y-W%W', created_at) as week,
          COUNT(*) as sale_count,
          SUM(total_amount) as total_revenue,
          AVG(total_amount) as avg_sale
        FROM sales
        WHERE tenant_id = ?
      `;
      const params = [tenantId];

      if (user.role === 'cashier') {
        query += ' AND user_id = ?';
        params.push(user.id);
      }

      if (startDate) {
        query += ' AND substr(created_at, 1, 10) >= ?';
        params.push(startDate);
      }
      if (endDate) {
        query += ' AND substr(created_at, 1, 10) <= ?';
        params.push(endDate);
      }

      query += ' GROUP BY week';
      query += ' ORDER BY week DESC';

      db.all(query, params, (err, rows) => {
        if (err) {
          console.error('Error fetching weekly sales:', err);
          return res.status(500).json({
            success: false,
            error: 'Failed to fetch weekly sales'
          });
        }

        res.json({
          success: true,
          data: rows
        });
      });
    } catch (error) {
      console.error('Error in getWeeklySalesReport:', error);
      res.status(500).json({
        success: false,
        error: error.message
      });
    }
  }

  // Monthly Sales Report
  getMonthlySalesReport(req, res) {
    try {
      const db = this.getDatabase();
      if (!db) {
        return res.status(500).json({
          success: false,
          error: 'Database access not configured'
        });
      }

      const { startDate, endDate } = req.query;
      const user = req.user;
      const tenantId = req.tenant_id;

      let query = `
        SELECT
          strftime('%Y-%m', created_at) as month,
          COUNT(*) as sale_count,
          SUM(total_amount) as total_revenue,
          AVG(total_amount) as avg_sale
        FROM sales
        WHERE tenant_id = ?
      `;
      const params = [tenantId];

      if (user.role === 'cashier') {
        query += ' AND user_id = ?';
        params.push(user.id);
      }

      if (startDate) {
        query += ' AND substr(created_at, 1, 10) >= ?';
        params.push(startDate);
      }
      if (endDate) {
        query += ' AND substr(created_at, 1, 10) <= ?';
        params.push(endDate);
      }

      query += ' GROUP BY month';
      query += ' ORDER BY month DESC';

      db.all(query, params, (err, rows) => {
        if (err) {
          console.error('Error fetching monthly sales:', err);
          return res.status(500).json({
            success: false,
            error: 'Failed to fetch monthly sales'
          });
        }

        res.json({
          success: true,
          data: rows
        });
      });
    } catch (error) {
      console.error('Error in getMonthlySalesReport:', error);
      res.status(500).json({
        success: false,
        error: error.message
      });
    }
  }

  // Top Selling Products
  getTopSellingProducts(req, res) {
    try {
      const db = this.getDatabase();
      if (!db) {
        return res.status(500).json({
          success: false,
          error: 'Database access not configured'
        });
      }

      const { startDate, endDate, limit = 20 } = req.query;
      const user = req.user;
      const tenantId = req.tenant_id;

      let query = `
        SELECT
          si.product_id,
          si.product_name,
          p.category,
          SUM(si.quantity) as total_quantity_sold,
          SUM(si.total_price) as total_revenue,
          COUNT(DISTINCT si.sale_id) as times_sold
        FROM sale_items si
        JOIN sales s ON si.sale_id = s.sale_id
        LEFT JOIN products p ON si.product_id = p.id
        WHERE s.tenant_id = ?
      `;
      const params = [tenantId];

      if (user.role === 'cashier') {
        query += ' AND s.user_id = ?';
        params.push(user.id);
      }

      if (startDate) {
        query += ' AND substr(s.created_at, 1, 10) >= ?';
        params.push(startDate);
      }
      if (endDate) {
        query += ' AND substr(s.created_at, 1, 10) <= ?';
        params.push(endDate);
      }

      query += ' GROUP BY si.product_id, si.product_name, p.category';
      query += ' ORDER BY total_quantity_sold DESC';
      query += ' LIMIT ?';
      params.push(parseInt(limit));

      db.all(query, params, (err, rows) => {
        if (err) {
          console.error('Error fetching top selling products:', err);
          return res.status(500).json({
            success: false,
            error: 'Failed to fetch top selling products'
          });
        }

        res.json({
          success: true,
          data: rows
        });
      });
    } catch (error) {
      console.error('Error in getTopSellingProducts:', error);
      res.status(500).json({
        success: false,
        error: error.message
      });
    }
  }

  // Low Selling Products
  getLowSellingProducts(req, res) {
    try {
      const db = this.getDatabase();
      if (!db) {
        return res.status(500).json({
          success: false,
          error: 'Database access not configured'
        });
      }

      const { startDate, endDate, limit = 20 } = req.query;
      const user = req.user;
      const tenantId = req.tenant_id;

      let query = `
        SELECT
          si.product_id,
          si.product_name,
          p.category,
          SUM(si.quantity) as total_quantity_sold,
          SUM(si.total_price) as total_revenue,
          COUNT(DISTINCT si.sale_id) as times_sold
        FROM sale_items si
        JOIN sales s ON si.sale_id = s.sale_id
        LEFT JOIN products p ON si.product_id = p.id
        WHERE s.tenant_id = ?
      `;
      const params = [tenantId];

      if (user.role === 'cashier') {
        query += ' AND s.user_id = ?';
        params.push(user.id);
      }

      if (startDate) {
        query += ' AND substr(s.created_at, 1, 10) >= ?';
        params.push(startDate);
      }
      if (endDate) {
        query += ' AND substr(s.created_at, 1, 10) <= ?';
        params.push(endDate);
      }

      query += ' GROUP BY si.product_id, si.product_name, p.category';
      query += ' ORDER BY total_quantity_sold ASC';
      query += ' LIMIT ?';
      params.push(parseInt(limit));

      db.all(query, params, (err, rows) => {
        if (err) {
          console.error('Error fetching low selling products:', err);
          return res.status(500).json({
            success: false,
            error: 'Failed to fetch low selling products'
          });
        }

        res.json({
          success: true,
          data: rows
        });
      });
    } catch (error) {
      console.error('Error in getLowSellingProducts:', error);
      res.status(500).json({
        success: false,
        error: error.message
      });
    }
  }

  // Product Profitability
  getProductProfitability(req, res) {
    try {
      const db = this.getDatabase();
      if (!db) {
        return res.status(500).json({
          success: false,
          error: 'Database access not configured'
        });
      }

      const { startDate, endDate } = req.query;
      const user = req.user;
      const tenantId = req.tenant_id;

      let query = `
        SELECT
          si.product_id,
          si.product_name,
          p.category,
          p.cost_price,
          AVG(si.unit_price) as avg_selling_price,
          SUM(si.quantity) as total_quantity_sold,
          SUM(si.total_price) as total_revenue,
          SUM(si.quantity * COALESCE(p.cost_price, 0)) as total_cost,
          SUM(si.total_price) - SUM(si.quantity * COALESCE(p.cost_price, 0)) as total_profit,
          CASE
            WHEN SUM(si.total_price) > 0
            THEN ((SUM(si.total_price) - SUM(si.quantity * COALESCE(p.cost_price, 0))) / SUM(si.total_price)) * 100
            ELSE 0
          END as profit_margin_percent
        FROM sale_items si
        JOIN sales s ON si.sale_id = s.sale_id
        LEFT JOIN products p ON si.product_id = p.id
        WHERE s.tenant_id = ?
      `;
      const params = [tenantId];

      if (user.role === 'cashier') {
        query += ' AND s.user_id = ?';
        params.push(user.id);
      }

      if (startDate) {
        query += ' AND substr(s.created_at, 1, 10) >= ?';
        params.push(startDate);
      }
      if (endDate) {
        query += ' AND substr(s.created_at, 1, 10) <= ?';
        params.push(endDate);
      }

      query += ' GROUP BY si.product_id, si.product_name, p.category, p.cost_price';
      query += ' HAVING total_revenue > 0';
      query += ' ORDER BY total_profit DESC';

      db.all(query, params, (err, rows) => {
        if (err) {
          console.error('Error fetching product profitability:', err);
          return res.status(500).json({
            success: false,
            error: 'Failed to fetch product profitability'
          });
        }

        res.json({
          success: true,
          data: rows
        });
      });
    } catch (error) {
      console.error('Error in getProductProfitability:', error);
      res.status(500).json({
        success: false,
        error: error.message
      });
    }
  }

  // Category Performance
  getCategoryPerformance(req, res) {
    try {
      const db = this.getDatabase();
      if (!db) {
        return res.status(500).json({
          success: false,
          error: 'Database access not configured'
        });
      }

      const { startDate, endDate } = req.query;
      const user = req.user;
      const tenantId = req.tenant_id;

      let query = `
        SELECT
          COALESCE(p.category, 'Uncategorized') as category,
          COUNT(DISTINCT si.product_id) as product_count,
          COUNT(DISTINCT si.sale_id) as sale_count,
          SUM(si.quantity) as total_quantity_sold,
          SUM(si.total_price) as total_revenue,
          AVG(si.unit_price) as avg_price
        FROM sale_items si
        JOIN sales s ON si.sale_id = s.sale_id
        LEFT JOIN products p ON si.product_id = p.id
        WHERE s.tenant_id = ?
      `;
      const params = [tenantId];

      if (user.role === 'cashier') {
        query += ' AND s.user_id = ?';
        params.push(user.id);
      }

      if (startDate) {
        query += ' AND substr(s.created_at, 1, 10) >= ?';
        params.push(startDate);
      }
      if (endDate) {
        query += ' AND substr(s.created_at, 1, 10) <= ?';
        params.push(endDate);
      }

      query += ' GROUP BY p.category';
      query += ' ORDER BY total_revenue DESC';

      db.all(query, params, (err, rows) => {
        if (err) {
          console.error('Error fetching category performance:', err);
          return res.status(500).json({
            success: false,
            error: 'Failed to fetch category performance'
          });
        }

        res.json({
          success: true,
          data: rows
        });
      });
    } catch (error) {
      console.error('Error in getCategoryPerformance:', error);
      res.status(500).json({
        success: false,
        error: error.message
      });
    }
  }

  // Product Performance Indicators
  getProductPerformanceIndicators(req, res) {
    try {
      const db = this.getDatabase();
      if (!db) {
        return res.status(500).json({
          success: false,
          error: 'Database access not configured'
        });
      }

      const { startDate, endDate } = req.query;
      const user = req.user;
      const tenantId = req.tenant_id;

      let query = `
        SELECT
          si.product_id,
          si.product_name,
          p.category,
          COUNT(DISTINCT si.sale_id) as sale_count,
          SUM(si.quantity) as total_quantity_sold,
          SUM(si.total_price) as total_revenue,
          AVG(si.unit_price) as avg_selling_price,
          p.cost_price,
          SUM(si.quantity * COALESCE(p.cost_price, 0)) as total_cost,
          SUM(si.total_price) - SUM(si.quantity * COALESCE(p.cost_price, 0)) as total_profit,
          CASE
            WHEN SUM(si.total_price) > 0
            THEN ((SUM(si.total_price) - SUM(si.quantity * COALESCE(p.cost_price, 0))) / SUM(si.total_price)) * 100
            ELSE 0
          END as profit_margin_percent,
          MIN(s.created_at) as first_sale,
          MAX(s.created_at) as last_sale
        FROM sale_items si
        JOIN sales s ON si.sale_id = s.sale_id
        LEFT JOIN products p ON si.product_id = p.id
        WHERE s.tenant_id = ?
      `;
      const params = [tenantId];

      if (user.role === 'cashier') {
        query += ' AND s.user_id = ?';
        params.push(user.id);
      }

      if (startDate) {
        query += ' AND substr(s.created_at, 1, 10) >= ?';
        params.push(startDate);
      }
      if (endDate) {
        query += ' AND substr(s.created_at, 1, 10) <= ?';
        params.push(endDate);
      }

      query += ' GROUP BY si.product_id, si.product_name, p.category, p.cost_price';
      query += ' HAVING total_revenue > 0';
      query += ' ORDER BY total_revenue DESC';

      db.all(query, params, (err, rows) => {
        if (err) {
          console.error('Error fetching product performance indicators:', err);
          return res.status(500).json({
            success: false,
            error: 'Failed to fetch product performance indicators'
          });
        }

        res.json({
          success: true,
          data: rows
        });
      });
    } catch (error) {
      console.error('Error in getProductPerformanceIndicators:', error);
      res.status(500).json({
        success: false,
        error: error.message
      });
    }
  }

  // Period Comparison
  getPeriodComparison(req, res) {
    try {
      const db = this.getDatabase();
      if (!db) {
        return res.status(500).json({
          success: false,
          error: 'Database access not configured'
        });
      }

      const { period1Start, period1End, period2Start, period2End } = req.query;
      const user = req.user;
      const tenantId = req.tenant_id;

      if (!period1Start || !period1End || !period2Start || !period2End) {
        return res.status(400).json({
          success: false,
          error: 'All period dates are required'
        });
      }

      const getPeriodStats = (start, end) => {
        return new Promise((resolve, reject) => {
          let query = `
            SELECT
              COUNT(*) as sale_count,
              SUM(total_amount) as total_revenue,
              AVG(total_amount) as avg_sale,
              MIN(total_amount) as min_sale,
              MAX(total_amount) as max_sale
            FROM sales
            WHERE tenant_id = ? AND substr(created_at, 1, 10) BETWEEN ? AND ?
          `;
          const params = [tenantId, start, end];

          if (user.role === 'cashier') {
            query += ' AND user_id = ?';
            params.push(user.id);
          }

          db.get(query, params, (err, row) => {
            if (err) {
              reject(err);
            } else {
              resolve(row);
            }
          });
        });
      };

      Promise.all([
        getPeriodStats(period1Start, period1End),
        getPeriodStats(period2Start, period2End)
      ]).then(([period1, period2]) => {
        const comparison = {
          period1: {
            ...period1,
            startDate: period1Start,
            endDate: period1End
          },
          period2: {
            ...period2,
            startDate: period2Start,
            endDate: period2End
          },
          changes: {
            revenueChange: period2.total_revenue - period1.total_revenue,
            revenueChangePercent: period1.total_revenue > 0 
              ? ((period2.total_revenue - period1.total_revenue) / period1.total_revenue) * 100 
              : 0,
            saleCountChange: period2.sale_count - period1.sale_count,
            saleCountChangePercent: period1.sale_count > 0 
              ? ((period2.sale_count - period1.sale_count) / period1.sale_count) * 100 
              : 0,
            avgSaleChange: period2.avg_sale - period1.avg_sale
          }
        };

        res.json({
          success: true,
          data: comparison
        });
      }).catch(err => {
        console.error('Error in period comparison:', err);
        res.status(500).json({
          success: false,
          error: 'Failed to compare periods'
        });
      });
    } catch (error) {
      console.error('Error in getPeriodComparison:', error);
      res.status(500).json({
        success: false,
        error: error.message
      });
    }
  }

  // Year Over Year Comparison
  getYearOverYearComparison(req, res) {
    try {
      const db = this.getDatabase();
      if (!db) {
        return res.status(500).json({
          success: false,
          error: 'Database access not configured'
        });
      }

      const { year } = req.query;
      const currentYear = year || new Date().getFullYear();
      const previousYear = currentYear - 1;
      const user = req.user;
      const tenantId = req.tenant_id;

      const getYearStats = (year) => {
        return new Promise((resolve, reject) => {
          let query = `
            SELECT
              strftime('%m', created_at) as month,
              COUNT(*) as sale_count,
              SUM(total_amount) as total_revenue,
              AVG(total_amount) as avg_sale
            FROM sales
            WHERE tenant_id = ? AND strftime('%Y', created_at) = ?
          `;
          const params = [tenantId, year.toString()];

          if (user.role === 'cashier') {
            query += ' AND user_id = ?';
            params.push(user.id);
          }

          query += ' GROUP BY month';
          query += ' ORDER BY month';

          db.all(query, params, (err, rows) => {
            if (err) {
              reject(err);
            } else {
              resolve(rows);
            }
          });
        });
      };

      Promise.all([
        getYearStats(currentYear),
        getYearStats(previousYear)
      ]).then(([currentYearData, previousYearData]) => {
        res.json({
          success: true,
          data: {
            currentYear: {
              year: currentYear,
              monthlyData: currentYearData
            },
            previousYear: {
              year: previousYear,
              monthlyData: previousYearData
            }
          }
        });
      }).catch(err => {
        console.error('Error in year over year comparison:', err);
        res.status(500).json({
          success: false,
          error: 'Failed to compare years'
        });
      });
    } catch (error) {
      console.error('Error in getYearOverYearComparison:', error);
      res.status(500).json({
        success: false,
        error: error.message
      });
    }
  }

  // Inventory Movement (simplified - would need inventory history table)
  getInventoryMovement(req, res) {
    try {
      const db = this.getDatabase();
      if (!db) {
        return res.status(500).json({
          success: false,
          error: 'Database access not configured'
        });
      }

      const { startDate, endDate } = req.query;
      const user = req.user;
      const tenantId = req.tenant_id;

      // This is a simplified version - would need proper inventory history tracking
      let query = `
        SELECT
          si.product_id,
          si.product_name,
          p.category,
          SUM(si.quantity) as quantity_sold,
          p.stock_quantity as current_stock
        FROM sale_items si
        JOIN sales s ON si.sale_id = s.sale_id
        LEFT JOIN products p ON si.product_id = p.id
        WHERE s.tenant_id = ?
      `;
      const params = [tenantId];

      if (user.role === 'cashier') {
        query += ' AND s.user_id = ?';
        params.push(user.id);
      }

      if (startDate) {
        query += ' AND substr(s.created_at, 1, 10) >= ?';
        params.push(startDate);
      }
      if (endDate) {
        query += ' AND substr(s.created_at, 1, 10) <= ?';
        params.push(endDate);
      }

      query += ' GROUP BY si.product_id, si.product_name, p.category, p.stock_quantity';
      query += ' ORDER BY quantity_sold DESC';

      db.all(query, params, (err, rows) => {
        if (err) {
          console.error('Error fetching inventory movement:', err);
          return res.status(500).json({
            success: false,
            error: 'Failed to fetch inventory movement'
          });
        }

        res.json({
          success: true,
          data: rows
        });
      });
    } catch (error) {
      console.error('Error in getInventoryMovement:', error);
      res.status(500).json({
        success: false,
        error: error.message
      });
    }
  }

  // Inventory Turnover
  getInventoryTurnover(req, res) {
    try {
      const db = this.getDatabase();
      if (!db) {
        return res.status(500).json({
          success: false,
          error: 'Database access not configured'
        });
      }

      const { startDate, endDate } = req.query;
      const user = req.user;
      const tenantId = req.tenant_id;

      let query = `
        SELECT
          si.product_id,
          si.product_name,
          p.category,
          p.stock_quantity,
          SUM(si.quantity) as quantity_sold,
          CASE
            WHEN p.stock_quantity > 0
            THEN CAST(SUM(si.quantity) AS REAL) / p.stock_quantity
            ELSE 0
          END as turnover_ratio
        FROM sale_items si
        JOIN sales s ON si.sale_id = s.sale_id
        LEFT JOIN products p ON si.product_id = p.id
        WHERE s.tenant_id = ?
      `;
      const params = [tenantId];

      if (user.role === 'cashier') {
        query += ' AND s.user_id = ?';
        params.push(user.id);
      }

      if (startDate) {
        query += ' AND substr(s.created_at, 1, 10) >= ?';
        params.push(startDate);
      }
      if (endDate) {
        query += ' AND substr(s.created_at, 1, 10) <= ?';
        params.push(endDate);
      }

      query += ' GROUP BY si.product_id, si.product_name, p.category, p.stock_quantity';
      query += ' HAVING quantity_sold > 0';
      query += ' ORDER BY turnover_ratio DESC';

      db.all(query, params, (err, rows) => {
        if (err) {
          console.error('Error fetching inventory turnover:', err);
          return res.status(500).json({
            success: false,
            error: 'Failed to fetch inventory turnover'
          });
        }

        res.json({
          success: true,
          data: rows
        });
      });
    } catch (error) {
      console.error('Error in getInventoryTurnover:', error);
      res.status(500).json({
        success: false,
        error: error.message
      });
    }
  }

  // Export to CSV
  exportToCSV(req, res) {
    try {
      const db = this.getDatabase();
      if (!db) {
        return res.status(500).json({
          success: false,
          error: 'Database access not configured'
        });
      }

      const { reportType, ...filters } = req.query;
      
      // This is a simplified version - would need to call appropriate report method
      // and convert to CSV format
      res.status(501).json({
        success: false,
        error: 'CSV export not yet implemented'
      });
    } catch (error) {
      console.error('Error in exportToCSV:', error);
      res.status(500).json({
        success: false,
        error: error.message
      });
    }
  }

  // Export to JSON
  exportToJSON(req, res) {
    try {
      // Redirect to the appropriate report endpoint
      res.status(501).json({
        success: false,
        error: 'JSON export - use the report endpoints directly'
      });
    } catch (error) {
      console.error('Error in exportToJSON:', error);
      res.status(500).json({
        success: false,
        error: error.message
      });
    }
  }

  // Dashboard Statistics
  getDashboardStats(req, res) {
    try {
      const db = this.getDatabase();
      if (!db) {
        return res.status(500).json({
          success: false,
          error: 'Database access not configured'
        });
      }

      const { startDate, endDate } = req.query;
      const user = req.user;
      const tenantId = req.tenant_id;

      // Get previous period for comparison
      let prevStartDate, prevEndDate;
      if (startDate && endDate) {
        const start = new Date(startDate);
        const end = new Date(endDate);
        const daysDiff = Math.ceil((end - start) / (1000 * 60 * 60 * 24));

        prevEnd = new Date(start);
        prevEnd.setDate(prevEnd.getDate() - 1);
        prevStart = new Date(prevEnd);
        prevStart.setDate(prevStart.getDate() - daysDiff);

        prevStartDate = prevStart.toISOString().split('T')[0];
        prevEndDate = prevEnd.toISOString().split('T')[0];
      }

      const getStats = (start, end) => {
        return new Promise((resolve, reject) => {
          let query = `
            SELECT
              COUNT(*) as sale_count,
              SUM(total_amount) as total_revenue,
              AVG(total_amount) as avg_sale
            FROM sales
            WHERE tenant_id = ?
          `;
          const params = [tenantId];

          if (user.role === 'cashier') {
            query += ' AND user_id = ?';
            params.push(user.id);
          }

          if (start) {
            query += ' AND substr(created_at, 1, 10) >= ?';
            params.push(start);
          }
          if (end) {
            query += ' AND substr(created_at, 1, 10) <= ?';
            params.push(end);
          }

          db.get(query, params, (err, row) => {
            if (err) {
              reject(err);
            } else {
              resolve(row);
            }
          });
        });
      };

      Promise.all([
        getStats(startDate, endDate),
        getStats(prevStartDate, prevEndDate)
      ]).then(([current, previous]) => {
        const revenueChange = current.total_revenue - (previous?.total_revenue || 0);
        const revenueChangePercent = previous?.total_revenue > 0 
          ? ((revenueChange / previous.total_revenue) * 100) 
          : 0;

        res.json({
          success: true,
          data: {
            current: {
              ...current,
              startDate,
              endDate
            },
            previous: previous ? {
              ...previous,
              startDate: prevStartDate,
              endDate: prevEndDate
            } : null,
            changes: {
              revenueChange,
              revenueChangePercent,
              saleCountChange: current.sale_count - (previous?.sale_count || 0)
            }
          }
        });
      }).catch(err => {
        console.error('Error fetching dashboard stats:', err);
        res.status(500).json({
          success: false,
          error: 'Failed to fetch dashboard statistics'
        });
      });
    } catch (error) {
      console.error('Error in getDashboardStats:', error);
      res.status(500).json({
        success: false,
        error: error.message
      });
    }
  }

  // Get frontend components provided by this module
  getFrontendComponents() {
    return {
      AdvancedReports: './frontend/AdvancedReports',
      metadata: {
        AdvancedReports: {
          name: 'AdvancedReports',
          description: 'Advanced reporting interface with enhanced filtering and analytics',
          usage: 'Reports page'
        }
      }
    };
  }
}

module.exports = new AdvancedReportingModule();

