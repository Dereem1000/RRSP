const bcrypt = require('bcryptjs');
const crypto = require('crypto');

class UserManagementModule {
  constructor() {
    this.name = 'pos-user-management';
    this.version = '1.0.0';
    this.dbConnector = null; // Database connector (supports local/remote)
    this.db = null; // Legacy support (deprecated)
    this.userPins = new Map(); // Store user PINs temporarily (in production, use database)
    this.pinSessions = new Map(); // Track PIN authentication sessions
    this.rolePermissions = {
      admin: {
        canManageUsers: true,
        canManageRoles: true,
        canAccessSettings: true,
        canModifySettings: true,
        canViewReports: true,
        canManageInventory: true,
        canProcessRefunds: true
      },
      manager: {
        canManageUsers: false, // Managers can't create/delete users, but can view
        canManageRoles: false,
        canAccessSettings: true,
        canModifySettings: true, // Limited settings
        canViewReports: true,
        canManageInventory: true,
        canProcessRefunds: true
      },
      cashier: {
        canManageUsers: false,
        canManageRoles: false,
        canAccessSettings: false,
        canModifySettings: false,
        canViewReports: false,
        canManageInventory: false,
        canProcessRefunds: false
      }
    };
  }

  // Initialize the module
  initialize(moduleManager, dbConnector = null) {
    this.moduleManager = moduleManager;
    
    // Use dbConnector (supports local/remote database)
    if (dbConnector) {
      this.dbConnector = dbConnector;
    } else if (moduleManager && moduleManager.dbConnector) {
      this.dbConnector = moduleManager.dbConnector;
    }
    
    console.log(`User Management module initialized${this.dbConnector ? ' with database connector (local/remote support)' : ' (database connection pending)'}`);
    
    // Add pay_rate column if it doesn't exist
    if (this.dbConnector) {
      this.migrateDatabase();
    }
    
    // Register API routes
    this.routes = this.getRoutes();
    
    // Setup middleware for role-based access control
    this.setupMiddleware();
  }

  // Migrate database to add pay_rate column
  async migrateDatabase() {
    try {
      const dbConnector = this.getDatabaseConnector();
      if (!dbConnector) return;

      // Check if pay_rate column exists (only works with local SQLite)
      // For remote databases, we'll skip this check as ALTER TABLE may not be supported
      try {
        const rows = await dbConnector.query("PRAGMA table_info(users)", []);
        const hasPayRate = rows && rows.some(row => row.name === 'pay_rate');
        
        if (!hasPayRate) {
          try {
            await dbConnector.run("ALTER TABLE users ADD COLUMN pay_rate REAL");
            console.log('Added pay_rate column to users table');
          } catch (alterErr) {
            // Remote databases may not support ALTER TABLE - this is expected
            if (alterErr.message && alterErr.message.includes('not allowed')) {
              console.log('ALTER TABLE not supported by remote database - skipping pay_rate column migration');
            } else {
              console.error('Error adding pay_rate column:', alterErr);
            }
          }
        }
      } catch (err) {
        // PRAGMA only works with local SQLite - skip for remote databases
        if (err.message && err.message.includes('PRAGMA')) {
          console.log('PRAGMA not supported by remote database - skipping column check');
        } else {
          console.error('Error checking table structure:', err);
        }
      }
    } catch (error) {
      console.error('Error in database migration:', error);
    }
  }

  // Setup middleware for role-based access control
  setupMiddleware() {
    // Middleware will be applied via routes
    console.log('User Management module middleware set up');
  }

  // Get API routes for this module
  getRoutes() {
    return [
      // User Management Routes
      {
        method: 'GET',
        path: '/user-management/users',
        handler: this.getUsers.bind(this),
        middleware: [this.requireAuth.bind(this), this.requireRole(['admin', 'manager'])]
      },
      {
        method: 'GET',
        path: '/user-management/users/:id',
        handler: this.getUser.bind(this),
        middleware: [this.requireAuth.bind(this)]
      },
      {
        method: 'POST',
        path: '/user-management/users',
        handler: this.createUser.bind(this),
        middleware: [this.requireAuth.bind(this), this.requireRole(['admin'])]
      },
      {
        method: 'PUT',
        path: '/user-management/users/:id',
        handler: this.updateUser.bind(this),
        middleware: [this.requireAuth.bind(this), this.requireRole(['admin', 'manager'])]
      },
      {
        method: 'DELETE',
        path: '/user-management/users/:id',
        handler: this.deleteUser.bind(this),
        middleware: [this.requireAuth.bind(this), this.requireRole(['admin'])]
      },
      {
        method: 'PUT',
        path: '/user-management/users/:id/role',
        handler: this.updateUserRole.bind(this),
        middleware: [this.requireAuth.bind(this), this.requireRole(['admin'])]
      },
      
      // PIN Authentication Routes
      {
        method: 'POST',
        path: '/user-management/pin/setup',
        handler: this.setupPin.bind(this),
        middleware: [this.requireAuth.bind(this)]
      },
      {
        method: 'POST',
        path: '/user-management/pin/verify',
        handler: this.verifyPin.bind(this),
        middleware: [this.requireAuth.bind(this)]
      },
      {
        method: 'POST',
        path: '/user-management/pin/clear',
        handler: this.clearPin.bind(this),
        middleware: [this.requireAuth.bind(this)]
      },
      {
        method: 'GET',
        path: '/user-management/pin/session/check',
        handler: this.checkPinSession.bind(this),
        middleware: [this.requireAuth.bind(this)]
      },
      {
        method: 'GET',
        path: '/user-management/pin/check-custom',
        handler: this.checkCustomPins.bind(this),
        middleware: [this.requireAuth.bind(this)]
      },
      {
        method: 'POST',
        path: '/user-management/verify-password',
        handler: this.verifyPassword.bind(this),
        middleware: [this.requireAuth.bind(this)]
      },
      
      // Settings Access Control Routes
      {
        method: 'GET',
        path: '/user-management/settings/check-access',
        handler: this.checkSettingsAccess.bind(this),
        middleware: [this.requireAuth.bind(this)]
      },
      {
        method: 'GET',
        path: '/user-management/settings/locked',
        handler: this.getLockedSettings.bind(this),
        middleware: [this.requireAuth.bind(this)]
      },
      
      // Role Permissions Routes
      {
        method: 'GET',
        path: '/user-management/roles',
        handler: this.getRoles.bind(this),
        middleware: [this.requireAuth.bind(this)]
      },
      {
        method: 'GET',
        path: '/user-management/permissions/:role',
        handler: this.getRolePermissions.bind(this),
        middleware: [this.requireAuth.bind(this)]
      }
    ];
  }

  // Middleware: Require authentication
  requireAuth(req, res, next) {
    if (req.session && req.session.user) {
      req.user = req.session.user;
      return next();
    }
    return res.status(401).json({
      success: false,
      error: 'Authentication required'
    });
  }

  // Middleware: Require specific role(s)
  requireRole(roles) {
    return (req, res, next) => {
      if (!req.user) {
        return res.status(401).json({
          success: false,
          error: 'Authentication required'
        });
      }

      const userRole = req.user.role;
      const allowedRoles = Array.isArray(roles) ? roles : [roles];
      
      if (allowedRoles.includes(userRole)) {
        return next();
      }
      
      return res.status(403).json({
        success: false,
        error: 'Insufficient permissions. Required role: ' + allowedRoles.join(' or ')
      });
    };
  }

  // Get database connector instance (supports local/remote)
  getDatabaseConnector() {
    if (this.dbConnector) {
      return this.dbConnector;
    }
    
    if (this.moduleManager && this.moduleManager.dbConnector) {
      return this.moduleManager.dbConnector;
    }
    
    return null;
  }

  // Legacy method for backward compatibility (deprecated - use getDatabaseConnector)
  getDatabase() {
    return null; // Force modules to use dbConnector
  }

  // Get all users
  async getUsers(req, res) {
    try {
      const dbConnector = this.getDatabaseConnector();
      if (!dbConnector) {
        return res.status(500).json({
          success: false,
          error: 'Database access not configured'
        });
      }

      const { role, is_active } = req.query;
      let query = 'SELECT id, username, role, full_name, email, is_active, pay_rate, created_at, last_login FROM users WHERE 1=1';
      const params = [];

      if (role) {
        query += ' AND role = ?';
        params.push(role);
      }

      if (is_active !== undefined) {
        query += ' AND is_active = ?';
        params.push(is_active === 'true' ? 1 : 0);
      }

      query += ' ORDER BY created_at DESC';

      const rows = await dbConnector.query(query, params);

      // Remove sensitive data
      const users = rows.map(user => ({
        ...user,
        // Don't include password
      }));

      res.json({
        success: true,
        users: users
      });
    } catch (error) {
      console.error('Error in getUsers:', error);
      res.status(500).json({
        success: false,
        error: error.message
      });
    }
  }

  // Get single user
  async getUser(req, res) {
    try {
      const dbConnector = this.getDatabaseConnector();
      if (!dbConnector) {
        return res.status(500).json({
          success: false,
          error: 'Database access not configured'
        });
      }

      const { id } = req.params;
      const userId = parseInt(id);

      // Users can only view their own profile unless they're admin/manager
      if (req.user.role !== 'admin' && req.user.role !== 'manager' && req.user.id !== userId) {
        return res.status(403).json({
          success: false,
          error: 'You can only view your own profile'
        });
      }

      const user = await dbConnector.get('SELECT id, username, role, full_name, email, is_active, pay_rate, created_at, last_login FROM users WHERE id = ?', [userId]);

      if (!user) {
        return res.status(404).json({
          success: false,
          error: 'User not found'
        });
      }

      res.json({
        success: true,
        user: user
      });
    } catch (error) {
      console.error('Error in getUser:', error);
      res.status(500).json({
        success: false,
        error: error.message
      });
    }
  }

  // Create new user
  async createUser(req, res) {
    try {
      const dbConnector = this.getDatabaseConnector();
      if (!dbConnector) {
        return res.status(500).json({
          success: false,
          error: 'Database access not configured'
        });
      }

      const { username, password, role, full_name, email } = req.body;

      // Validation
      if (!username || !password) {
        return res.status(400).json({
          success: false,
          error: 'Username and password are required'
        });
      }

      const validRoles = ['admin', 'manager', 'cashier'];
      if (role && !validRoles.includes(role)) {
        return res.status(400).json({
          success: false,
          error: `Invalid role. Must be one of: ${validRoles.join(', ')}`
        });
      }

      // Hash password
      const hashPassword = (password) => {
        return crypto.createHash('sha256').update(password).digest('hex');
      };

      const hashedPassword = hashPassword(password);
      const userRole = role || 'cashier';

      // Check if username already exists
      const existingUser = await dbConnector.get('SELECT id FROM users WHERE username = ?', [username]);

      if (existingUser) {
        return res.status(400).json({
          success: false,
          error: 'Username already exists'
        });
      }

      // Insert new user
      const result = await dbConnector.run(
        `INSERT INTO users (username, password, role, full_name, email, is_active, created_at) 
         VALUES (?, ?, ?, ?, ?, 1, datetime('now'))`,
        [username, hashedPassword, userRole, full_name || null, email || null]
      );

      // Fetch the created user
      const newUser = await dbConnector.get('SELECT id, username, role, full_name, email, is_active, pay_rate, created_at FROM users WHERE id = ?', [result.lastID]);

      res.json({
        success: true,
        message: 'User created successfully',
        user: newUser
      });
    } catch (error) {
      console.error('Error in createUser:', error);
      res.status(500).json({
        success: false,
        error: error.message
      });
    }
  }

  // Update user
  async updateUser(req, res) {
    try {
      const dbConnector = this.getDatabaseConnector();
      if (!dbConnector) {
        return res.status(500).json({
          success: false,
          error: 'Database access not configured'
        });
      }

      const { id } = req.params;
      const { username, password, full_name, email, is_active, pay_rate } = req.body;
      const userId = parseInt(id);

      // Build update query dynamically
      const updates = [];
      const params = [];

      if (username !== undefined) {
        updates.push('username = ?');
        params.push(username);
      }

      if (password !== undefined) {
        const hashPassword = (password) => {
          return crypto.createHash('sha256').update(password).digest('hex');
        };
        updates.push('password = ?');
        params.push(hashPassword(password));
      }

      if (full_name !== undefined) {
        updates.push('full_name = ?');
        params.push(full_name);
      }

      if (email !== undefined) {
        updates.push('email = ?');
        params.push(email);
      }

      if (is_active !== undefined) {
        updates.push('is_active = ?');
        params.push(is_active ? 1 : 0);
      }

      if (pay_rate !== undefined) {
        updates.push('pay_rate = ?');
        params.push(pay_rate !== null && pay_rate !== '' ? parseFloat(pay_rate) : null);
      }

      if (updates.length === 0) {
        return res.status(400).json({
          success: false,
          error: 'No fields to update'
        });
      }

      params.push(userId);

      const query = `UPDATE users SET ${updates.join(', ')} WHERE id = ?`;

      await dbConnector.run(query, params);

      // Fetch updated user
      const updatedUser = await dbConnector.get('SELECT id, username, role, full_name, email, is_active, pay_rate, created_at, last_login FROM users WHERE id = ?', [userId]);

      res.json({
        success: true,
        message: 'User updated successfully',
        user: updatedUser
      });
    } catch (error) {
      console.error('Error in updateUser:', error);
      res.status(500).json({
        success: false,
        error: error.message
      });
    }
  }

  // Delete user
  async deleteUser(req, res) {
    try {
      const dbConnector = this.getDatabaseConnector();
      if (!dbConnector) {
        return res.status(500).json({
          success: false,
          error: 'Database access not configured'
        });
      }

      const { id } = req.params;
      const userId = parseInt(id);

      // Prevent deleting yourself
      if (req.user.id === userId) {
        return res.status(400).json({
          success: false,
          error: 'You cannot delete your own account'
        });
      }

      // Check if user exists
      const user = await dbConnector.get('SELECT id, username FROM users WHERE id = ?', [userId]);

      if (!user) {
        return res.status(404).json({
          success: false,
          error: 'User not found'
        });
      }

      // Delete user
      await dbConnector.run('DELETE FROM users WHERE id = ?', [userId]);

      res.json({
        success: true,
        message: `User ${user.username} deleted successfully`
      });
    } catch (error) {
      console.error('Error in deleteUser:', error);
      res.status(500).json({
        success: false,
        error: error.message
      });
    }
  }

  // Update user role
  async updateUserRole(req, res) {
    try {
      const dbConnector = this.getDatabaseConnector();
      if (!dbConnector) {
        return res.status(500).json({
          success: false,
          error: 'Database access not configured'
        });
      }

      const { id } = req.params;
      const { role } = req.body;
      const userId = parseInt(id);

      const validRoles = ['admin', 'manager', 'cashier'];
      if (!role || !validRoles.includes(role)) {
        return res.status(400).json({
          success: false,
          error: `Invalid role. Must be one of: ${validRoles.join(', ')}`
        });
      }

      // Prevent changing your own role
      if (req.user.id === userId) {
        return res.status(400).json({
          success: false,
          error: 'You cannot change your own role'
        });
      }

      await dbConnector.run('UPDATE users SET role = ? WHERE id = ?', [role, userId]);

      // Fetch updated user
      const updatedUser = await dbConnector.get('SELECT id, username, role, full_name, email, is_active FROM users WHERE id = ?', [userId]);

      res.json({
        success: true,
        message: 'User role updated successfully',
        user: updatedUser
      });
    } catch (error) {
      console.error('Error in updateUserRole:', error);
      res.status(500).json({
        success: false,
        error: error.message
      });
    }
  }

  // Setup PIN for user
  setupPin(req, res) {
    try {
      const { pin } = req.body;
      const userId = req.user.id;

      if (!pin || pin.length < 4 || pin.length > 8) {
        return res.status(400).json({
          success: false,
          error: 'PIN must be between 4 and 8 digits'
        });
      }

      if (!/^\d+$/.test(pin)) {
        return res.status(400).json({
          success: false,
          error: 'PIN must contain only digits'
        });
      }

      // Hash and store PIN (in production, store in database)
      const hashedPin = bcrypt.hashSync(pin, 10);
      this.userPins.set(userId, hashedPin);

      res.json({
        success: true,
        message: 'PIN set up successfully'
      });
    } catch (error) {
      console.error('Error in setupPin:', error);
      res.status(500).json({
        success: false,
        error: error.message
      });
    }
  }

  // Verify PIN
  verifyPin(req, res) {
    try {
      const { pin } = req.body;
      
      // Check if user is authenticated
      if (!req.user || !req.user.id) {
        return res.status(401).json({
          success: false,
          error: 'Authentication required. Please log in first.'
        });
      }
      
      const userId = req.user.id;

      if (!pin) {
        return res.status(400).json({
          success: false,
          error: 'PIN is required'
        });
      }

      const hashedPin = this.userPins.get(userId);
      if (!hashedPin) {
        // Get default PIN from module settings
        // Try to get from saved settings first, then from package.json schema
        const config = this.moduleManager.moduleConfigs.get(this.name);
        const settings = config?.settings || {};
        
        // Handle both schema format (with .default) and saved value format
        let defaultPin = '0000';
        
        if (settings.defaultPin) {
          if (typeof settings.defaultPin === 'string') {
            // It's a saved value
            defaultPin = settings.defaultPin;
          } else if (settings.defaultPin.default) {
            // It's a schema object
            defaultPin = settings.defaultPin.default;
          }
        } else {
          // If not in settings, try to get from package.json
          try {
            const path = require('path');
            const fs = require('fs');
            const packagePath = path.join(__dirname, '..', 'installed', this.name, 'package.json');
            if (fs.existsSync(packagePath)) {
              const packageData = JSON.parse(fs.readFileSync(packagePath, 'utf8'));
              if (packageData.settings?.defaultPin?.default) {
                defaultPin = packageData.settings.defaultPin.default;
              }
            }
          } catch (err) {
            console.error('Error reading package.json for default PIN:', err);
            // Fall back to '0000'
          }
        }
        
        // Allow default PIN if user hasn't set up their own
        if (pin === defaultPin) {
          // Create PIN session using default PIN
          let timeout = 300 * 1000; // Default 5 minutes
          if (settings.pinTimeout) {
            if (typeof settings.pinTimeout === 'number') {
              timeout = settings.pinTimeout * 1000;
            } else if (settings.pinTimeout.default) {
              timeout = settings.pinTimeout.default * 1000;
            }
          }
          
          const sessionId = crypto.randomBytes(32).toString('hex');
          this.pinSessions.set(sessionId, {
            userId: userId,
            expiresAt: Date.now() + timeout
          });
          
          this.cleanupExpiredSessions();
          
          return res.json({
            success: true,
            message: 'Default PIN accepted. Please set up your own PIN in Profile settings.',
            sessionId: sessionId,
            expiresAt: new Date(Date.now() + timeout).toISOString(),
            expiresIn: timeout / 1000,
            isDefaultPin: true
          });
        }
        
        return res.status(404).json({
          success: false,
          error: 'PIN not set up for this user',
          defaultPin: defaultPin,
          message: `PIN not set up for this user. Use default PIN: ${defaultPin}`
        });
      }

      const isValid = bcrypt.compareSync(pin, hashedPin);
      if (!isValid) {
        return res.status(401).json({
          success: false,
          error: 'Invalid PIN'
        });
      }

      // Create PIN session (valid for configured timeout)
      const settings = this.moduleManager.moduleConfigs.get(this.name)?.settings || {};
      const timeout = (settings.pinTimeout?.default || 300) * 1000; // Convert to milliseconds
      
      const sessionId = crypto.randomBytes(32).toString('hex');
      this.pinSessions.set(sessionId, {
        userId: userId,
        expiresAt: Date.now() + timeout
      });

      // Clean up expired sessions
      this.cleanupExpiredSessions();

      res.json({
        success: true,
        message: 'PIN verified successfully',
        sessionId: sessionId,
        expiresIn: timeout / 1000 // seconds
      });
    } catch (error) {
      console.error('Error in verifyPin:', error);
      res.status(500).json({
        success: false,
        error: error.message
      });
    }
  }

  // Clear PIN
  clearPin(req, res) {
    try {
      const userId = req.user.id;
      this.userPins.delete(userId);

      // Clear all sessions for this user
      for (const [sessionId, session] of this.pinSessions.entries()) {
        if (session.userId === userId) {
          this.pinSessions.delete(sessionId);
        }
      }

      res.json({
        success: true,
        message: 'PIN cleared successfully'
      });
    } catch (error) {
      console.error('Error in clearPin:', error);
      res.status(500).json({
        success: false,
        error: error.message
      });
    }
  }

  // Check if PIN session is valid
  isPinSessionValid(sessionId) {
    const session = this.pinSessions.get(sessionId);
    if (!session) {
      return false;
    }

    if (Date.now() > session.expiresAt) {
      this.pinSessions.delete(sessionId);
      return false;
    }

    return true;
  }

  // Clean up expired PIN sessions
  cleanupExpiredSessions() {
    const now = Date.now();
    for (const [sessionId, session] of this.pinSessions.entries()) {
      if (now > session.expiresAt) {
        this.pinSessions.delete(sessionId);
      }
    }
  }

  // Verify password for viewing pay rate
  async verifyPassword(req, res) {
    try {
      const userId = req.user.id;
      const { password } = req.body;

      if (!password) {
        return res.status(400).json({
          success: false,
          error: 'Password is required'
        });
      }

      const dbConnector = this.getDatabaseConnector();
      if (!dbConnector) {
        return res.status(500).json({
          success: false,
          error: 'Database access not configured'
        });
      }

      // Get user's password hash from database
      const user = await dbConnector.get('SELECT password FROM users WHERE id = ?', [userId]);

      if (!user) {
        return res.status(404).json({
          success: false,
          error: 'User not found'
        });
      }

      // Hash the provided password
      const hashPassword = (password) => {
        return crypto.createHash('sha256').update(password).digest('hex');
      };

      const hashedPassword = hashPassword(password);

      // Compare passwords
      if (hashedPassword === user.password) {
        res.json({
          success: true,
          message: 'Password verified'
        });
      } else {
        res.status(401).json({
          success: false,
          error: 'Incorrect password'
        });
      }
    } catch (error) {
      console.error('Error verifying password:', error);
      res.status(500).json({
        success: false,
        error: error.message
      });
    }
  }

  // Check if any users have custom PINs set up
  checkCustomPins(req, res) {
    try {
      // Check if userPins Map has any entries (users with custom PINs)
      const hasCustomPins = this.userPins.size > 0;
      
      res.json({
        success: true,
        hasCustomPins: hasCustomPins,
        count: this.userPins.size
      });
    } catch (error) {
      console.error('Error checking custom PINs:', error);
      res.status(500).json({
        success: false,
        error: 'Failed to check custom PINs'
      });
    }
  }

  // Check PIN session validity
  async checkPinSession(req, res) {
    try {
      const userId = req.user.id;
      const sessionId = req.query.sessionId || req.headers['x-pin-session-id'];
      
      if (!sessionId) {
        return res.json({
          success: false,
          valid: false,
          hasPin: !!this.userPins.get(userId),
          message: 'No PIN session ID provided'
        });
      }

      const isValid = this.isPinSessionValid(sessionId);
      const hasPin = !!this.userPins.get(userId);
      
      // If user has a PIN set up, they need a valid session
      // If user doesn't have a PIN, they can use default PIN
      if (hasPin && !isValid) {
        return res.json({
          success: false,
          valid: false,
          hasPin: true,
          message: 'PIN session expired or invalid'
        });
      }

      res.json({
        success: true,
        valid: isValid,
        hasPin: hasPin,
        message: isValid ? 'PIN session is valid' : 'No PIN session required'
      });
    } catch (error) {
      console.error('Error checking PIN session:', error);
      res.status(500).json({
        success: false,
        error: error.message
      });
    }
  }

  // Check settings access based on role
  checkSettingsAccess(req, res) {
    try {
      const userRole = req.user.role;
      const permissions = this.rolePermissions[userRole] || this.rolePermissions.cashier;

      const settings = this.moduleManager.moduleConfigs.get(this.name)?.settings || {};
      const lockSettingsByRole = settings.lockSettingsByRole?.default !== false;

      let accessibleSettings = [];
      let lockedSettings = [];

      if (lockSettingsByRole) {
        // Define which settings each role can access
        const settingsAccess = {
          admin: ['all'], // Admin can access all settings
          manager: [
            'inventory',
            'products',
            'reports',
            'sales',
            'tax',
            'receipt',
            'printer'
          ],
          cashier: [] // Cashiers cannot access settings
        };

        const userAccess = settingsAccess[userRole] || [];
        
        if (userAccess.includes('all')) {
          accessibleSettings = ['all'];
          lockedSettings = [];
        } else {
          accessibleSettings = userAccess;
          // All other settings are locked
          lockedSettings = [
            'system',
            'database',
            'license',
            'users',
            'security',
            'backup',
            'advanced'
          ].filter(setting => !userAccess.includes(setting));
        }
      } else {
        // If locking is disabled, all users can access all settings
        accessibleSettings = ['all'];
      }

      res.json({
        success: true,
        canAccessSettings: permissions.canAccessSettings,
        canModifySettings: permissions.canModifySettings,
        accessibleSettings: accessibleSettings,
        lockedSettings: lockedSettings,
        role: userRole
      });
    } catch (error) {
      console.error('Error in checkSettingsAccess:', error);
      res.status(500).json({
        success: false,
        error: error.message
      });
    }
  }

  // Get locked settings for current user
  getLockedSettings(req, res) {
    try {
      const userRole = req.user.role;
      const permissions = this.rolePermissions[userRole] || this.rolePermissions.cashier;

      const settings = this.moduleManager.moduleConfigs.get(this.name)?.settings || {};
      const lockSettingsByRole = settings.lockSettingsByRole?.default !== false;

      if (!lockSettingsByRole) {
        return res.json({
          success: true,
          locked: false,
          lockedSettings: []
        });
      }

      const settingsAccess = {
        admin: [],
        manager: [
          'system',
          'database',
          'license',
          'users',
          'security',
          'backup',
          'advanced'
        ],
        cashier: [
          'system',
          'database',
          'license',
          'users',
          'security',
          'backup',
          'advanced',
          'inventory',
          'products',
          'reports',
          'sales',
          'tax',
          'receipt',
          'printer'
        ]
      };

      const locked = settingsAccess[userRole] || settingsAccess.cashier;

      res.json({
        success: true,
        locked: locked.length > 0,
        lockedSettings: locked,
        role: userRole
      });
    } catch (error) {
      console.error('Error in getLockedSettings:', error);
      res.status(500).json({
        success: false,
        error: error.message
      });
    }
  }

  // Get all available roles
  getRoles(req, res) {
    try {
      const roles = [
        {
          name: 'admin',
          displayName: 'Administrator',
          description: 'Full system access with all permissions',
          permissions: this.rolePermissions.admin
        },
        {
          name: 'manager',
          displayName: 'Manager',
          description: 'Management access with limited administrative permissions',
          permissions: this.rolePermissions.manager
        },
        {
          name: 'cashier',
          displayName: 'Cashier',
          description: 'Basic access for point-of-sale operations',
          permissions: this.rolePermissions.cashier
        }
      ];

      res.json({
        success: true,
        roles: roles
      });
    } catch (error) {
      console.error('Error in getRoles:', error);
      res.status(500).json({
        success: false,
        error: error.message
      });
    }
  }

  // Get permissions for a specific role
  getRolePermissions(req, res) {
    try {
      const { role } = req.params;
      const permissions = this.rolePermissions[role];

      if (!permissions) {
        return res.status(404).json({
          success: false,
          error: 'Role not found'
        });
      }

      res.json({
        success: true,
        role: role,
        permissions: permissions
      });
    } catch (error) {
      console.error('Error in getRolePermissions:', error);
      res.status(500).json({
        success: false,
        error: error.message
      });
    }
  }

  // Helper method to set database reference
  setDatabase(db) {
    this.db = db;
  }

  // Helper method to check if user has permission
  hasPermission(userRole, permission) {
    const permissions = this.rolePermissions[userRole];
    return permissions && permissions[permission] === true;
  }

  // Helper method to check if settings are locked for user
  isSettingLocked(userRole, settingName) {
    const settings = this.moduleManager.moduleConfigs.get(this.name)?.settings || {};
    const lockSettingsByRole = settings.lockSettingsByRole?.default !== false;

    if (!lockSettingsByRole) {
      return false;
    }

    const settingsAccess = {
      admin: ['all'],
      manager: [
        'inventory',
        'products',
        'reports',
        'sales',
        'tax',
        'receipt',
        'printer'
      ],
      cashier: []
    };

    const userAccess = settingsAccess[userRole] || [];
    
    if (userAccess.includes('all')) {
      return false;
    }

    return !userAccess.includes(settingName);
  }

  // Get frontend components provided by this module
  getFrontendComponents() {
    return {
      // Component paths relative to module frontend folder
      PinManagement: './frontend/PinManagement',
      LockScreen: './frontend/LockScreen',
      // Component metadata
      metadata: {
        PinManagement: {
          name: 'PinManagement',
          description: 'PIN setup and management component',
          usage: 'Profile page, Settings'
        },
        LockScreen: {
          name: 'LockScreen',
          description: 'Lock screen for when user is away',
          usage: 'Global overlay when session is locked'
        }
      }
    };
  }
}

module.exports = new UserManagementModule();

